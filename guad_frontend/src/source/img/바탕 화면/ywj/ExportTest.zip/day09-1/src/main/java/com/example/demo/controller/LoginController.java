package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {

	@RequestMapping("/main")
	public String mainFunc() {
		return "main"; // main.html
	}

	@RequestMapping("/loginForm")
	public String loginForm() {
		System.out.println("test");
		return "login_form"; // login_form.html
	}

	// 로그인폼에서 로그인정보인 form태그 input에 입력한 값을 받아 비교하여 어떤 뷰를 보여줄지에대한 컨트롤러를 작성
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	// 리턴할 값이 있을 경우 ModelAndView 자료형을 쓴다.
	public ModelAndView login(@RequestParam("userId") String id, @RequestParam("userPw") String pw) {

		ModelAndView mv = new ModelAndView();

		if (id.equals("admin") && pw.equals("1234")) {
			mv.addObject("loginId", id);
			mv.setViewName("login_success");
		} else {
			mv.setViewName("login_fail");
		}
		return mv;
	}
}
