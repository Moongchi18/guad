package sample_scorp_singleton;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class test {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context =
				new ClassPathXmlApplicationContext("sample_scorp_singleton/applicationContext.xml");

		Computer c1 = context.getBean("computer", Computer.class);
		Computer c2 = context.getBean("computer", Computer.class);

		System.out.println("컴퓨터 1 : " + c1.toString());
		System.out.println("컴퓨터 2 : " + c2.toString());
		// toString으로 power 값을 가져오면 power 값을 private 할 수있다.
		// 직접접근에 비해서 상대적으로 안전
		c1.offPower();

		System.out.println("컴퓨터 1 : " + c1.toString());
		System.out.println("컴퓨터 2 : " + c2.toString());
	}
}
