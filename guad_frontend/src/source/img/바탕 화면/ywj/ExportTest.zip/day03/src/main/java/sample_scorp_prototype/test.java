package sample_scorp_prototype;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class test {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context =
				new ClassPathXmlApplicationContext("sample_scorp_prototype/applicationContext.xml");
		
		//bean 작성을 통해 생성된  객체
		Sample ss1 = context.getBean("sample" , Sample.class);
		Sample ss2 = context.getBean("sample" , Sample.class);

		System.out.println(ss1);
		System.out.println(ss2);

		//Annotation을 통해 자동 생성된 객체
		Sample sss1 = context.getBean("sss", Sample.class);
		Sample sss2 = context.getBean("sss", Sample.class);
		
		System.out.println(sss1);
		System.out.println(sss2);
	
	}

}
