package with;

import org.springframework.context.support.ClassPathXmlApplicationContext;


public class User {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("with/applicationContext.xml");
		
		Keyboard myBoard = context.getBean("CK108", Keyboard.class);

		myBoard.keyboardInfo();


	}

}
