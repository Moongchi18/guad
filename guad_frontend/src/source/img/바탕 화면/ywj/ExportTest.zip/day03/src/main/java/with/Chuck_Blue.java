package with;

public class Chuck_Blue implements Chuck {
	private String model = "Blue";
	
	public String getModel() {
		return model;
	}

}
