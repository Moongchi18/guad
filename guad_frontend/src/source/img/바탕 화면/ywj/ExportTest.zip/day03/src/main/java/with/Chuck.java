package with;

public interface Chuck {
	public String getModel();
}
