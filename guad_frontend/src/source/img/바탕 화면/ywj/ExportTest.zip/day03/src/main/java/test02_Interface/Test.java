package test02_Interface;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import test02_Interface.Sample;

public class Test {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext context =
				new ClassPathXmlApplicationContext("test02_Interface/applicationContext.xml");
		
		Sample s = context.getBean("sample", Sample.class);
		s.sampleFunc(); //사용단계
		
		context.close();
		///object 메서드 cloas() 서버를 닫는데 사용.
	}
}
