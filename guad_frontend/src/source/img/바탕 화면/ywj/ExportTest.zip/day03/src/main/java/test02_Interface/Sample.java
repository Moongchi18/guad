package test02_Interface;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Sample implements InitializingBean, DisposableBean {
	public Sample() {
		System.out.println("Sample 생성자 호출됨!");
	}

	public void sampleFunc() {
		System.out.println("샘플 객체 사용중~~");

	}
	//// lifeCycle 관련 메소드

	@Override // 초기화 메소드
	public void afterPropertiesSet() throws Exception {
		System.out.println("생성 직후 afterPropertiesSet");
	}

	@Override // 소멸메소드
	public void destroy() throws Exception {
		System.out.println("소멸 직전 destroy");
	}
}
