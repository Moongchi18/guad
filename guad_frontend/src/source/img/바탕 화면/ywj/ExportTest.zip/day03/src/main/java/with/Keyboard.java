package with;



public class Keyboard {
	private Chuck chuck;
	private String Color;
	private Boolean keyskin;
	
	Keyboard(Chuck chuck) {
		this.chuck = chuck;
	}
	
	public void setColor(String Color) {
		this.Color = Color;
	}
	//get만 is로 
	public void setKeyskin(Boolean keyskin) {
		this.keyskin = keyskin;
	}
	
	public void keyboardInfo() {
		System.out.println("현재 키보드의 색상 : " + Color + "키스킨 여부 : " + keyskin + "축 종류 : " + chuck.getModel());
	}
}
