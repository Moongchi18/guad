package with;

public class Chuck_Red implements Chuck{
		private String model = "RED";
		
		public String getModel() {
			return model;
	}
}
