package with;

public class Chuck_Black implements Chuck{

	private String model = "BLACK";
	
	public String getModel() {
		return model;
	}
}
