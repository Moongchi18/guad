package sample_scorp_prototype;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("sss") //어노테이션(스캔)으로 설정할수 있는 id 값은 하나만 가능하다
					// 추가적인 id 등록을 위해선 직접 xml파일에 bean을 생성

@Scope("prototype")
public class Sample {

	// 객체 생성을 위한 샘플 클래스
	// 스프링 컨테이너 applicationContext.xml에 이클래스로
	// 객체를 등록할 예정.
}
