package test01;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.stereotype.Component;

@Component("sample")
public class Sample {
	public Sample() {
		System.out.println("Sample 생성자 호출됨!");
	}

	public void sampleFunc() {
		System.out.println("샘플 객체 사용중~~");
		
	}

	////lifeCycle 관련 메소드
	
	@PostConstruct
	public void myStart() {
		System.out.println("myStart() 메소드 호출됨!!");

	}
	@PreDestroy
	public void myFinish() {
		System.out.println("myFinish() 메소드 호출됨!!!");
	}
}
