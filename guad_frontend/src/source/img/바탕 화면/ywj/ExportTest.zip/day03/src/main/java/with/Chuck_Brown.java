package with;

public class Chuck_Brown implements Chuck {

	private String model = "BROWN";
	
	public String getModel() {
		return model;
}
}
