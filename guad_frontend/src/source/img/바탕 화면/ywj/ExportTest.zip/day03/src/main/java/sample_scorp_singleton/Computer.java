package sample_scorp_singleton;

import org.springframework.stereotype.Component;


public class Computer {
	 boolean power;
	
	
		Computer() {
			power = true;
			System.out.println("컴퓨터를 켰습니다.");
		}
		
		public void offPower() {
			System.out.println("컴퓨터의 전원을 껐습니다.");
			power = false;
		}
		
		public String toString() {
			return "전원 : " + power;
		}
		
}

