package test_xml;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class test {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext context =
				new ClassPathXmlApplicationContext("test_xml/applicationContext.xml");
		
		Sample s = context.getBean("sample", Sample.class);
		s.sampleFunc(); //사용단계
		
		context.close();
		///object 메서드 cloas() 서버를 닫는데 사용.
		
		
	}

}
