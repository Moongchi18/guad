package repository.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import vo.UserVo;


public interface UserMapper {

	public int insert(UserVo user);
	public int update(@Param("user") UserVo user, @Param("UserNum") int UserNum);
	public int delete(int UserNum);
	
	public List<UserVo> selectList();
	
	
}
