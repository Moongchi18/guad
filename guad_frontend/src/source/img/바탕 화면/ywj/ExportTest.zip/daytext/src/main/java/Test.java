
import org.springframework.context.support.ClassPathXmlApplicationContext;
import repository.mapper.UserDao;
import vo.UserVo;



public class Test {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		UserDao dao = context.getBean("dao", UserDao.class);
		
		UserVo user = new UserVo();
		
		user.setjName("용원철");
		user.setjId("ywj2016");
		user.setjOld(44);
		user.setjPassword("0102447");
		
//		System.out.println("추가 결과 : " + dao.insert(user));
		System.out.println("수정 결과 : " + dao.update(user, 4));
//		System.out.println("삭제 결과 : " + dao.delete(5));
		
		for(UserVo u : dao.selectList()) {
			System.out.println(u);
		}
	}

}
