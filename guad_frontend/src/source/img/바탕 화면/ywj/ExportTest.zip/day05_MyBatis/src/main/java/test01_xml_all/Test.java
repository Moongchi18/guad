package test01_xml_all;

import vo.BookVo;

public class Test {

	public static void main(String[] args) {

		BookDao dao = new BookDao();

		BookVo book = new BookVo(); // 입력할 객체 생성

		book.setjTitle("자바"); // 객체 데이터 입력
		book.setjPublisher("봉출판"); // 객체 데이터 입력
		book.setjWriter("aaaaa"); // 객체 데이터 입력
		book.setjPrice(25000); // 객체 데이터 입력

//		System.out.println("insert 결과 : " + dao.insertBook(book));
//		System.out.println("update 결과 : " + dao.updateBook(book));
//		System.out.println("delete 결과 : " + dao.deleteBook(13));

		for (BookVo b : dao.selectList()) { // 전체 데이터 조회
			System.out.println(b);
		}

		System.out.println(dao.select(9)); // 특정 데이터 조회
	}
}
