package test01_xml;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import vo.BookVo;

public class BookDao {
	private SqlSessionFactory factory;

	public BookDao() {
		// 마이바티스 설정파일 읽어들이기
		String resource = "test01_xml/conf.xml";

		// 어느 한쪽에서 다른 쪽으로 데이터를 전달하려면,
		// 두 대상을 연결하고 데이터를 전송할 수 있는 무언가가 필요한데 이것을 스트림 이라고함
		InputStream is = null;

		try {
			is = Resources.getResourceAsStream(resource);
			factory = new SqlSessionFactoryBuilder().build(is);
		} catch (IOException ex) {
			System.out.println("마이바티스 설정파일 에러");
			ex.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public int insertBook(BookVo book) { // 데이터 입력
		SqlSession session = factory.openSession(true);
		return session.insert("kbm.insert", book);
	}

	public List<BookVo> selectList() { // 데이터 전체 조회
		SqlSession session = factory.openSession();
		return session.selectList("kbm.selectList");
	}

	public BookVo select(int bookNum) { // 특정 데이터 조회
		SqlSession session = factory.openSession();
		return session.selectOne("kbm.selectBook", bookNum);
	}

}