package test06_SpringAop_Annotation;

public interface Person {

	public void doSomething() throws Exception;
}
