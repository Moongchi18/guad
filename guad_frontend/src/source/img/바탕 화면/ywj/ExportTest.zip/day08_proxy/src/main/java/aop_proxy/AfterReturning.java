package aop_proxy;

public interface AfterReturning {
	public void doAfterReturning();
}
