package aop_proxy;

public interface AfterThrowing {
	public void doAfterThrowing();
}
