package test06_SpringAop_Annotation;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) throws Exception {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"test06_SpringAop_Annotation/applicationContext.xml");

		Person p = context.getBean("boy", Person.class);
		p.doSomething();
	}
}
