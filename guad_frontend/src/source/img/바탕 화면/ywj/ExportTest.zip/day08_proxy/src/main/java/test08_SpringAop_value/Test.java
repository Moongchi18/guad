package test08_SpringAop_value;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) throws Exception {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("test08_SpringAop_value/applicationContext.xml");

		Person p = context.getBean("boy", Person.class);
		p.doSomething(8);
	}
}
