package test06_SpringAop_Annotation;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class MyAspect {

	// 공통 관심사항을 bean인 boy에 적용시키고
	// myPoint메소드를 Poincut으로 지정
	@Pointcut("bean(boy)")
	public void myPoint() {
	}
//<aop:pointcut expression="execution(String doSomething(int))" id="myPoint/>

//해당경로 예 : test06패키지 하위에 있는 do로 시작하는 파라미터가 0개이상인
// 모든 메소드	
//	@Pointcut("execution(* test06..*do*(..))")
//	public void myPoint() {}

	@Before("myPoint()")
	public void myBefore() {
		System.out.println("배가 고프다.");
	}

	@AfterReturning("myPoint()")
	public void myAfterReturning() {
		System.out.println("음식을 먹는다.");
	}

	@AfterThrowing("myPoint()")
	public void myAfterThrowing() {
		System.out.println("엄마를 부른다");
	}

	@After("myPoint()")
	public void myAfter() {
		System.out.println("설거지를 한다.");
	}
}
