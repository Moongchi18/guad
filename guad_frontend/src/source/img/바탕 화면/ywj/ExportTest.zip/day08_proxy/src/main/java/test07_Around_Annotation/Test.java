package test07_Around_Annotation;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) throws Exception {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"test07_Around_Annotation/applicationContext.xml");

		Person p = context.getBean("boy", Person.class);
		p.doSomething();
	}
}
