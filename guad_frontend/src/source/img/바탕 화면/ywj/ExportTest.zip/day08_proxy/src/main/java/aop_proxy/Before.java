package aop_proxy;

public interface Before {
	public void doBefore();
}
