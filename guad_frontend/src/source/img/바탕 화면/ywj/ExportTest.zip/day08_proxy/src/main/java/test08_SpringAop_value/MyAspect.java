package test08_SpringAop_value;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class MyAspect {
	@Pointcut("execution(String doSomething(int))")
	public void myPoint() {
	}

	@Before(value = "myPoint()")
	public void myBefore(JoinPoint joinPoint) {
		Object[] param = joinPoint.getArgs();
		int n = (Integer) param[0];

		System.out.println("미리받은 숫자 : " + n);
		System.out.println("배가 고프다");

	}

	@AfterReturning(value = "myPoint()", returning = "result")
	public void afterReturning(Object result) {
		System.out.println("음식을 먹는다");
		System.out.println("핵심사항 결과 :" + result);
	}

	@AfterThrowing(value = "myPoint()", throwing = "ex")
	public void afterThrowing(Throwable ex) {
		System.out.println("핵심관심사항 도중 에러");
		System.out.println(ex.getMessage());
	}

	@After("myPoint()")
	public void after() {
		System.out.println("설거지는 ... 해야지...");
	}

}
