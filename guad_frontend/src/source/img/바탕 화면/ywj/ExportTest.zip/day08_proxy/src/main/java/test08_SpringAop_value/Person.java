package test08_SpringAop_value;

public interface Person {

	public String doSomething(int n) throws Exception;
}

