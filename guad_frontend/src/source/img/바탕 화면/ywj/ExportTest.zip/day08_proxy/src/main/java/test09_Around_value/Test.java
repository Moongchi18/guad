package test09_Around_value;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) throws Exception {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"test09_Around_value/applicationContext.xml");

		Person p = context.getBean("boy", Person.class);
		p.doSomething(8);
	}
}
