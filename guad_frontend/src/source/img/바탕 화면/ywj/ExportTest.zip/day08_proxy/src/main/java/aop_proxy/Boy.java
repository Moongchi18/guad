package aop_proxy;

import java.util.Random;

public class Boy implements Person {

	@Override
	public String doSomething(int arg) throws Exception {
		System.out.println("냉면를 만든다" + arg + "인분");
		
		if(new Random().nextBoolean()) {
			throw new Exception("불났다!!!");
		}
		return "맛있는 냉면을 완성했다.";
	}
}
