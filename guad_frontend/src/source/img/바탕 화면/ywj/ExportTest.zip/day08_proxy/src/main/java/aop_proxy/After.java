package aop_proxy;

public interface After {
	public void doAfter();
}
