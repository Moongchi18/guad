package aop_proxy;

public interface Person {
	public String doSomething(int arg) throws Exception;
}
