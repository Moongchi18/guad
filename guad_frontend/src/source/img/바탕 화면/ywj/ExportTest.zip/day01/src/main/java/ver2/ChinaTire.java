package ver2;

public class ChinaTire implements Tire {

	private String model = "대륙 타이어"
;
	public String getModel() {
		return model;
	}
}
