package ver1;

public class Driever {

	public static void main(String[] args) {

		Car myCar = new Car();
		myCar.printCarInfo();
	}
}
