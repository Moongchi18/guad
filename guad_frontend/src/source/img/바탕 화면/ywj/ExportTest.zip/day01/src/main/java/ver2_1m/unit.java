package ver2_1m;

public interface unit {
	
	public String getName();
}
