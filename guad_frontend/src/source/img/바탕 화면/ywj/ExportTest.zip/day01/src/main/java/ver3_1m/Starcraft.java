package ver3_1m;

 

public class Starcraft {
	private Unit U;
	
	public void setUnit(Unit U) {
		this.U = U;
	}
	
	public void printInfostacraft() {
		System.out.println("현재 선택한 유닛은 : " + U.getName());
	}
	
}
