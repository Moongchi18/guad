package ver1;

public class Car {
//   private KoreaTire koreaTire;
	private ChinaTire chinaTire;

	// 차량에 장착할 타이어 변경을 하고싶으면
	// Car 클래스 설계도를 뜯어 고쳐야 하는 문제상황 발생.
	// 왜??
	// 의존성이높아 결합도가 높음.

	public Car() {
//      koreaTire = new KoreaTire();
		chinaTire = new ChinaTire();
	}

	public void printCarInfo() {
		System.out.println("현재 장착된 타이어 :" + chinaTire.getModel());
	}

}
