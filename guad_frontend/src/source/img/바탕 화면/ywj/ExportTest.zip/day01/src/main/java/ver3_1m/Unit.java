package ver3_1m;

public interface Unit {
	
	public String getName();
}
