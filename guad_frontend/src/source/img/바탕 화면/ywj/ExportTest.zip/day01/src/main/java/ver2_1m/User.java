package ver2_1m;

public class User {

	public static void main(String[] args) {
		
		Marin m = new Marin();
		
		starcraft s = new starcraft(m);
		
		s.printInfostacraft();

	}

}
