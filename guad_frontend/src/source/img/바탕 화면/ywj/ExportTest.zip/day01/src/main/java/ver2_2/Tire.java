package ver2_2;

public interface Tire {

	public String getModel();
	
}
