package ver2_1m;

public class Marin implements unit{
	String name = "Marin";
	
	public String getName() {
		return name;
	}
}
