package ver1;

public class ChinaTire {

	private String model = "대륙 타이어";

	public String getModel() {
		return model;
	}
}
