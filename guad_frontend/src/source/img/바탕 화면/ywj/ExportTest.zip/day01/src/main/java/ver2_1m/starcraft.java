package ver2_1m;

public class starcraft {
	private unit U;
	
	public starcraft(unit U) {
		this.U = U;
	}
	
	public void printInfostacraft() {
		System.out.println("현재 선택한 유닛은 : " + U.getName());
	}
	
}
