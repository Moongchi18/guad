package ver3_1m;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class User {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext context =
				new ClassPathXmlApplicationContext("ver3_1m/applicationContext.xml");
		
		Starcraft S = context.getBean("Star", Starcraft.class);
		Unit U = context.getBean("Marin", Unit.class);
		
		
		S.setUnit(U);
		S.printInfostacraft();
		
		
		
	}

}
