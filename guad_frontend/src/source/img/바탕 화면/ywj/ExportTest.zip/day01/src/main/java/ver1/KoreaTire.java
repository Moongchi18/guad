package ver1;

public class KoreaTire {

	private String model = "한국타이어";

	public String getModel() {
		return model;
	}

}
