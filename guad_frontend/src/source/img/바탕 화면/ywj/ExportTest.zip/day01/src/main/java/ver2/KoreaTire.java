package ver2;

public class KoreaTire implements Tire{

	private String model = "한국 타이어";
	
	public String getModel() {
		return model;
	}
}
