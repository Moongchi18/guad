package ver3_1m;

public class Tank implements Unit{
	String name = "Tank";
	
	public String getName() {
		return name;
	}
}
