package ver2;

public interface Tire {

	public String getModel();
	
}
