package ver2;

public class Car {
		
	private Tire tire;
	
	public Car(Tire tire) {
		//외부에서 타이어객체(KoreaTire or ChinaTire)를
		//주입받아 멤버에 장착시키기.
		this.tire = tire;
	}
	
	public void printCarInfo() {
		System.out.println("현자 장착된 타이어: " +tire.getModel());
	}
}
