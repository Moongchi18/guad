package ver2_1m;

public class Tank implements unit{
	String name = "Tank";
	
	public String getName() {
		return name;
	}
}
