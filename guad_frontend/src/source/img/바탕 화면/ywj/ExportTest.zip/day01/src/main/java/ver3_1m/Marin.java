package ver3_1m;

public class Marin implements Unit{
	String name = "Marin";
	
	public String getName() {
		return name;
	}
}
