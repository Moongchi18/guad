package ver3;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Driver {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("ver3/applicationContext.xml");
		// xml 파일에 있는 빈을 사용하기 위한 객체생성과 xml파일 경로 지정.

		// 차와 타이어 둘다 new해서 객체를 생성하지 않고,
		// 빈에 만들어둔 객체를 getBean()메소드를 통해 가져와서 조립.

		Car myCar = context.getBean("sonata", Car.class);
		// Tire tire = context.getBean("chinaTire",Tire.class);
		Tire tire = context.getBean("koreaTire", Tire.class);

		myCar.setTire(tire);
		myCar.printCarInfo();

		// 해당 버전은 겹합도가 느슨해졌고, 의존성이 강하지 않지만,
		// 조립이 되어 있지 않아
		// 차와 타이어를 각각getBean()함
	}

}
