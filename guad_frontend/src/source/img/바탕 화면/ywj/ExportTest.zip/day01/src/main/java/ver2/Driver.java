package ver2;

public class Driver {

	public static void main(String[] args) {
		
		KoreaTire koreaTire = new KoreaTire();
		Car myCar =new Car(koreaTire); //겹합도가 낮아졌다.
		myCar.printCarInfo();

	}
}
