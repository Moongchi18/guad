package ver2_2;

public class Driver {

	public static void main(String[] args) {

		Car myCar = new Car();
		KoreaTire koreaTire = new KoreaTire();
		ChinaTire chinaTire = new ChinaTire();

		myCar.setTire(koreaTire);
		myCar.printCarInfo();

	}
}
