package ver6;



//객체 이름 안 쓰면 기본적으로 클래스이름 첫글자만 소문자로 해서 이름이 됨.
//chinaTire

public class ChinaTire implements Tire {
	private String model = "대륙 타이어";
	
	public String getModel() {
		return model;
	}
}
