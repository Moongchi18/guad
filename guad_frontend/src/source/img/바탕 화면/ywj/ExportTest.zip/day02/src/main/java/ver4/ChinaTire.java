package ver4;

import ver4_2.Tire;

public class ChinaTire implements Tire{
	private String model = "대륙타이어";
	
	public String getModel() {
			return model;
	}
}
