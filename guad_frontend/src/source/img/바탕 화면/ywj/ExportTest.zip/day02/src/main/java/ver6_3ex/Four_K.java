package ver6_3ex;

public class Four_K implements Quality{
		private String resolution = "4K";
		
		public String getQuality() {
			return resolution;
		}
}

