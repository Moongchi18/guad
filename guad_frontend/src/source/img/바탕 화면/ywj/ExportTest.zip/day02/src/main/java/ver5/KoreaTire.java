package ver5;

import org.springframework.stereotype.Component;

import ver4_2.Tire;

@Component
public class KoreaTire implements Tire{
	private String model = "한국 타이어";
	
	public String getModel() {
		return model;
	}
}
