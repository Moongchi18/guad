package ver4_2;

public interface Tire {

	public String getModel();
	
	
}
