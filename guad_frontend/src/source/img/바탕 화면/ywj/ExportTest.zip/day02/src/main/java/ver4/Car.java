package ver4;



public class Car{

	private Tire tire;
	public Car(Tire tire) {
		this.tire = tire;
		
	}
	
	public void printCarInfo() {
		System.out.println("현재 장착된 타이어 :" +tire.getModel());
	}
}
