package ver6_3ex;

public class QHD implements Quality{
	private String resolution = "QHD";
	
	public String getQuality() {
		return resolution;
	}
}

