package ver6_3ex;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class User {
	public static void main(String[] args) {

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("ver6_3ex/applicationContext.xml");

		Monitor M = context.getBean("mmm", Monitor.class);

		M.printMonitrInfor();

	}

}
