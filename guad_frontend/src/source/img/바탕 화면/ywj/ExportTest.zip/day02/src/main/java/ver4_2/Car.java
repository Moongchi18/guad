package ver4_2;

public class Car {

		private Tire tire;
		private String color;
		
		public void setTire(Tire tire) {
			this.tire = tire;
		}
		
		public void setColor(String color) {
			this.color = color;
		}
		
		public void printCarInfo() {
			System.out.println("현재 장탁된 타이어 : " + tire.getModel());
			System.out.println("차량 색상 : " + color);
		}
}
