package ver6_3ex;

public class FHD implements Quality {
	private String resolution = "FHD";
	
	public String getQuality() {
		return resolution;
	}
}
