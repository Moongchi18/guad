package ver6_1;

public interface Tire {

	public String getModel();
	
	
}
