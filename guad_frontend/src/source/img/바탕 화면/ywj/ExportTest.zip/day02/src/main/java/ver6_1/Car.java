package ver6_1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("sonata")
public class Car {
	@Autowired(required = false)
	private Tire tire;

	public void printCarInfo() {
		if (tire == null) {
			System.out.println("데이터가 없음");

		} else {
			System.out.println("현재 장착된 타이어 " + tire.getModel());
		}
	}
}
