package ver6_2;

public interface Tire {

	public String getModel();
	
	
}
