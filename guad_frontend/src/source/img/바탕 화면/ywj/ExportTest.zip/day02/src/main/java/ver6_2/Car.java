package ver6_2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("sonata")
public class Car {
	@Autowired(required = false)
	@Qualifier("chinaTire") // 해당 타이어 쓸거야
	private Tire tire;

	public void printCarInfo() {
		if (tire == null) {
			System.out.println("데이터가 없음");

		} else {
			System.out.println("현재 장착된 타이어 " + tire.getModel());
		}
	}
}
