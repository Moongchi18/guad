package ver6_3ex;



public class Monitor {
	private Quality quality;
	
	public void getQuality(Quality quality) {
		this.quality = quality;
	}
	
	public void printMonitrInfor() {
		System.out.println("모니터의 화질 : " + quality.getQuality());
		
	}
}
