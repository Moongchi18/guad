package ver6_3ex;

public interface Quality {
	
	public String getQuality();
	
}
