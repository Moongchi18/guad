package ver6_1;

import org.springframework.stereotype.Component;

@Component
public class KoreaTire implements Tire{
	private String model = "한국 타이어";
	
	public String getModel() {
		return model;
	}
}
