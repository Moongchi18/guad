package ver6;

public interface Tire {

	public String getModel();
	
	
}
