package ver5;

public interface Tire {

	public String getModel();
	
	
}
