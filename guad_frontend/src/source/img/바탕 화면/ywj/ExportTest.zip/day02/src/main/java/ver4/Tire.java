package ver4;

public interface Tire {

	public String getModel();
	
	
}
