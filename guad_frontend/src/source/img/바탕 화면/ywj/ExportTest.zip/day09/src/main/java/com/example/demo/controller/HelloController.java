package com.example.demo.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

public class HelloController implements Controller {
	// 핸들러가 요청에 맞는 컨트롤러 선택하여 필요한 컨트롤러 메소드 호출

	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {

		// 여기선 데이터를 딱히 보내주진 않을거임.
		ModelAndView mv = new ModelAndView();

		// 응답해줄 View 지정
		mv.setViewName("index");
		return mv;
	}
}
