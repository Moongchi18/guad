package com.example.demo.controller;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

//스프링 프레임워크에게 해당 클래스를 Controller로 사용하겠다고 알린다.
@Controller
public class HelloController {

	@RequestMapping("/hello")
	public ModelAndView getMessage() {

		// ModelAndView에 데이터정보, 뷰를 지정해서 반환해줌
		ModelAndView mv = new ModelAndView();

		mv.addObject("now", new Date());
		mv.addObject("test", "안녕하세요. 스프링MVC 두번째 실습입니다.");
		mv.setViewName("sample");

		return mv;

	}

}
