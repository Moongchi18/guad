package test03_xml_interface;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import vo.BookVo;

public interface BookMapper {

	
	public int insert(BookVo book);
	
	
	
	//파라미터 값을 넘겨줘야 한다.
	public BookVo selectBook();
	
	//꼭 jBookNum이 아니여도 된다 그저 변수
	public BookVo selectBook(@Param("bookNum") int jBookNum , @Param("title") String jTitle);
	
	public List<BookVo> selectList();
}
