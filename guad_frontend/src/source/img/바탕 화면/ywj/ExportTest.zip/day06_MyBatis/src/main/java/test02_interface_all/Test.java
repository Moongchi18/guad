package test02_interface_all;

import vo.BookVo;

public class Test {

	public static void main(String[] args) {

		BookDao dao = new BookDao();

		BookVo book = new BookVo(); // 입력할 객체 생성

		book.setjTitle("자바up"); // 객체 데이터 입력
		book.setjPublisher("봉출판up"); // 객체 데이터 입력
		book.setjWriter("aaaaaup"); // 객체 데이터 입력
		book.setjPrice(25000); // 객체 데이터 입력
		book.setjBookNum(4);

//		System.out.println("insert 결과 : " + dao.insertBook(book)); //인서트 결과 및 데이터 입력
		System.out.println("update 결과 : " + dao.updateBook(book)); // 인서트 결과 및 데이터 입력
//		System.out.println("delete 결과 : " + dao.deleteBook(3)); //인서트 결과 및 데이터 입력

		for (BookVo b : dao.selectList()) { // 전체 데이터 조회
			System.out.println(b);
		}

		System.out.println(dao.select(1)); // 특정 데이터 조회
	}
}
