package test03_xml_interface_all;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import vo.BookVo;

public interface BookMapper {

//	아이디랑 java메퍼 메서드명이랑 일치
	public int insert(BookVo book);
	
	public int update(@Param("booK")BookVo book, @Param("bookNum") int BookNum);
	
	public int delete(int bookNum);
	
	//파라미터 값을 넘겨줘야 한다.
	public BookVo selectBook();
	
	//꼭 jBookNum이 아니여도 된다 그저 변수
	public BookVo selectBook(@Param("bookNum") int jBookNum , @Param("title") String jTitle);
	
	public List<BookVo> selectList();
}
