package test04_Spring_Mybatis;

import vo.BookVo;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import test04_Spring_Mybatis.BookDao;

public class Test {
	public static void main(String[] args) {
//		스프링과 바티스를 둘다 사용
//		아래처럼 new해버리면 Dao가 의존하는
//		SqlSessionTemplate 객체가 없는 Dao가 생성됨.
//		써먹을데가 없다.
//		BookDao dao = new BookDao();

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"test04_Spring_Mybatis/applicationContext.xml");

		BookDao dao = context.getBean("dao", BookDao.class);

		BookVo book = new BookVo();
		book.setjTitle("새로운 책");
		book.setjPrice(10000);
		book.setjPublisher("출판사");
		book.setjWriter("저자 누구");

//		System.out.println(dao.insert(book));
		System.out.println(dao.update(book, 26));
//		System.out.println(dao.delete(29));

		for (BookVo b : dao.selectList()) {
			System.out.println(b);
		}
	}
}
