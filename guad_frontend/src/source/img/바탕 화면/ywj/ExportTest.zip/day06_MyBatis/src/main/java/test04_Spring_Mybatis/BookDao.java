package test04_Spring_Mybatis;

import java.util.List;


import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import vo.BookVo;

@Component("dao")
public class BookDao {
	@Autowired
	private SqlSessionTemplate session;

	public void setSession(SqlSessionTemplate session) {
		// splsession을 만들어준다.
		this.session = session;
	}
	////////////////////////////////////////

	public int insert(BookVo book) {
		BookMapper mapper = session.getMapper(BookMapper.class);
		return mapper.insert(book);
	}

	public int update(BookVo book, int BookNum) {
		BookMapper mapper = session.getMapper(BookMapper.class);
		return mapper.update(book, BookNum);
	}
	
	public int delete(int bookNum) {
		BookMapper mapper = session.getMapper(BookMapper.class);
		return mapper.delete(bookNum);
	}
	
	public List<BookVo> selectList() {
		BookMapper mapper = session.getMapper(BookMapper.class);
		return mapper.selectList();
	}
}
