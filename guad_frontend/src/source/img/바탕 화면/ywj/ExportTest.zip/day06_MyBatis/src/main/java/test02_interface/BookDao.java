package test02_interface;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import vo.BookVo;

public class BookDao {
	private SqlSessionFactory factory;

	public BookDao() {
		// 마이바티스 설정파일 읽어들이기
		String resource = "test02_interface/conf.xml";

		// 어느 한쪽에서 다른 쪽으로 데이터를 전달하려면,
		// 두 대상을 연결하고 데이터를 전송할 수 있는 무언가가 필요한데 이것을 스트림 이라고함
		InputStream is = null;

		try {
			is = Resources.getResourceAsStream(resource);
			factory = new SqlSessionFactoryBuilder().build(is);
		} catch (IOException ex) {
			System.out.println("마이바티스 설정파일 에러");
			ex.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

//	public int insertBook(BookVo book) { // 데이터 입력
//		SqlSession session = factory.openSession(true);
//		return session.insert("kbm.insert", book);
//	}
//
//	public List<BookVo> selectList() { // 데이터 전체 조회
//		SqlSession session = factory.openSession();
//		return session.selectList("kbm.selectList");
//	}
//
//	public BookVo select(int bookNum) { // 특정 데이터 조회
//		SqlSession session = factory.openSession();
//		return session.selectOne("kbm.selectBook", bookNum);
//	}
	
	public int insertBook(BookVo book) {
		SqlSession session = factory.openSession(true);
		//SqlSession 객체를 얻을 때 openSession(true)와 같이 호출하면 INSERT, UPDATE, DELETE문 실행 시 auto commit을 수행하는 SqlSession 객체를 얻을 수 있다.
		//auto commit : 데이터 베이스의 작업을 즉시 반영한다.
		BookMapper mapper = session.getMapper(BookMapper.class);
		return mapper.insert(book);
	}
	
	public List<BookVo> selectList() {
		SqlSession session = factory.openSession();
		BookMapper mapper = session.getMapper(BookMapper.class);
		return mapper.selectList();
	}
	
	public BookVo select(int bookNum) {
		SqlSession session = factory.openSession();
		BookMapper mapper = session.getMapper(BookMapper.class);
		return mapper.selectBook(bookNum);
	}
	
	
	
	
	
	
	
}