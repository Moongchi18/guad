package test04_Spring_Mybatis;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import vo.BookVo;

public interface BookMapper {

	public int insert(BookVo book);
	public List<BookVo> selectList();
	
	public int update(@Param("book") BookVo book, @Param("BookNum") int BookNum) ;
	public int delete(int jbookNum);
}
