package test02_interface_all;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import vo.BookVo;

public interface BookMapper {
	// 쿼리문 만들어두기

	public final String INSERT_SQL = "INSERT INTO BOOK(TITLE,PUBLISHER,PRICE,WRITER)"
			+ "VALUES(#{jTitle},#{jPublisher},#{jPrice},#{jWriter})";
	public final String UPDATE_SQL = "UPDATE BOOK SET TITLE=#{jTitle},WRITER=#{jWriter},PRICE=#{jPrice},PUBLISHER=#{jPublisher}"
			+ "WHERE BOOK_NUM=#{jBookNum}";
	public final String DELETE_SQL = "DELETE FROM BOOK WHERE BOOK_NUM=#{jbookNum}";
	public final String SELECT_SQL = "SELECT * FROM BOOK WHERE BOOK_NUM=#{jBookNum}";
	public final String SELECT_ALL_SQL = "SELECT * FROM BOOK";

	// 어노테이션으로 만들어둔 쿼리문 추상메소드에 적용
	@Insert(INSERT_SQL)
	public int insert(BookVo book);

	@Update(UPDATE_SQL)
	public int update(BookVo book);

	@Delete(DELETE_SQL)
	public int delete(int jBookNum);

	// 특정번호 조회
	// @Results 어노테이션으로 컬럼과 멤버들을 매핑시켜줘야함.
	@Select(SELECT_SQL)
	@Results({ @Result(column = "BOOK_NUM", property = "jBookNum"),
			@Result(column = "PUBLISHER", property = "jPublisher"), @Result(column = "TITLE", property = "jTitle"),
			@Result(column = "PRICE", property = "jPrice"), @Result(column = "WRITER", property = "jWriter"), })
	public BookVo selectBook(int jBookNum);

//	<resultMap type="BookVo" id="bookResultMap">
//	<result column="BOOK_NUM" property="jBookNum" />
//	<result column="TITLE" property="jTitle" />
//	<result column="PUBLISHER" property="jPublisher" />
//	<result column="PRICE" property="jPrice" />
//	<result column="WRITER" property="jWriter" />
//	</resultMap>

	@Select(SELECT_ALL_SQL)
	@Results({ @Result(column = "BOOK_NUM", property = "jBookNum"),
			@Result(column = "PUBLISHER", property = "jPublisher"), @Result(column = "TITLE", property = "jTitle"),
			@Result(column = "PRICE", property = "jPrice"), @Result(column = "WRITER", property = "jWriter"), })
	public List<BookVo> selectList();

}
