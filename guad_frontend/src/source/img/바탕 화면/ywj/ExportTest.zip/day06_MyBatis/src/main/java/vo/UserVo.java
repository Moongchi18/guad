package vo;

public class UserVo {
	
	private int jUserNum;
	private String jName;
	private String jId;
	private int jOld;
	private int jPassword;
	
	
	@Override
	public String toString() {
		return "UserVo [jUserNum=" + jUserNum + ", jName=" + jName + ", jId=" + jId + ", jOld=" + jOld + ", jPassword="
				+ jPassword + "]";
	}
	
	public int getjUserNum() {
		return jUserNum;
	}
	public void setjUserNum(int jUserNum) {
		this.jUserNum = jUserNum;
	}
	public String getjName() {
		return jName;
	}
	public void setjName(String jName) {
		this.jName = jName;
	}
	public String getjId() {
		return jId;
	}
	public void setjId(String jId) {
		this.jId = jId;
	}
	public int getjOld() {
		return jOld;
	}
	public void setjOld(int jOld) {
		this.jOld = jOld;
	}
	public int getjPassword() {
		return jPassword;
	}
	public void setjPassword(int jPassword) {
		this.jPassword = jPassword;
	}
	
}
