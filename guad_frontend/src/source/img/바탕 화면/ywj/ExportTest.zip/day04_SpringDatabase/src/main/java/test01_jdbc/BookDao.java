package test01_jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import vo.BookVo;

public class BookDao {
	public int insertBook(BookVo book) { //데이터베이스에 데이터 입력
		Connection con = null;
		PreparedStatement pstmt = null;
		int result = 0;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/spring", "root", "1234");
			String sql = "insert into Book" + "(TITLE,PRICE,PUBLISHER,WRITER)" + "VALUES(?,?,?,?)";

			pstmt = con.prepareStatement(sql);

			pstmt.setString(1, book.getTitle());
			pstmt.setInt(2, book.getPrice());
			pstmt.setString(3, book.getPublisher());
			pstmt.setString(4, book.getWriter());

			result = pstmt.executeUpdate(); // SQL 실행

		} catch (ClassNotFoundException e) {
			System.out.println("드리이버 로딩 오류");
			e.printStackTrace();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if (con != null) {
				try {
					con.close();

				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;
	}

	// 웹(react) 에서 처럼 select문은 값을 받을 때 전체를 불러오게되면 하나의 값이아닌 여러개 값이 날아오기떄문에,
	// 배열구조로 가져와서 보여줘야함.
	// 배열에 담긴 순서대로 가져와서 목록을 보여줘야 하기때문에 순서가 있는 목록인 List형 컬렉션을 사용.

	public List<BookVo> selectAll() { //데이터베이스의 데이터 조회
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<BookVo> resultList = new ArrayList<>();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/spring", "root", "1234");

			String sql = "select BOOK_NUM,TITLE," + "PRICE,PUBLISHER,WRITER FROM BOOK";

			pstmt = con.prepareStatement(sql);

			rs = pstmt.executeQuery(); // sql 실행

			while (rs.next()) { //여러 행(객체)를 가져오기 때문에 반복문을 사용
				BookVo b = new BookVo();
				b.setBookNum(rs.getInt(1));
				b.setTitle(rs.getString(2));
				b.setPrice(rs.getInt(3));
				b.setPublisher(rs.getString(4));
				b.setWriter(rs.getString(5));

				resultList.add(b);
			}
		} catch (ClassNotFoundException e) {
			System.out.println("드리이버 로딩 오류");
			e.printStackTrace();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if (con != null) {
				try {
					con.close();

				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return resultList;
	}
}
