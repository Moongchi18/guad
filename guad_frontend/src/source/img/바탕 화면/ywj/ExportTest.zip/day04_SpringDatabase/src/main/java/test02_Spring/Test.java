package test02_Spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import vo.BookVo;

public class Test {

	public static void main(String[] args) {
		// 객체 아래처럼 new 하면 안된다.
		// BookDaoSpring dao = new BookDaoSpring();

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"test02_Spring/applicationContext.xml");

		// dataSource 객체, jdbc Template 객체 장착된
		// 완제품 객체 가져오기

		BookDaoSpring dao = context.getBean("dao", BookDaoSpring.class); //component-scan
		
		BookVo book = new BookVo("스프링 책", "저자", 30000, "봉출판"); // import한 BookVo 클래스 생성
		System.out.println("insert 결과 : " + dao.insert(book)); //데이터 입력 및 입력결과 출력

		// 책 목록보기
		for (BookVo b : dao.selectBookList()) {	//전체 데이터 조회
			System.out.println(b);	
		}

		System.out.println(dao.selectBook(3)); //특정 데이터 조회
	}
}
