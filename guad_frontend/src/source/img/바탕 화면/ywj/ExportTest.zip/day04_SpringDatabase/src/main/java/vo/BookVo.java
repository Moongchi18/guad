package vo;

public class BookVo {

	private int bookNum;
	private String title;
	private String writer;
	private int price;
	private String publisher;

	// 해당 메소드는 쿼리문 실행시 사용할 컬럼들
	// 프로그램에서 책정보 입력시 필요한 값들을 생성자 매개변수로 적어줌.
	public BookVo(int bookNum, String title, String writer, int price, String publisher) {
		this.bookNum = bookNum;
		this.title = title;
		this.writer = writer;
		this.price = price;
		this.publisher = publisher;
	}

	public BookVo(String title, String writer, int price, String publisher) {
		this.title = title;
		this.writer = writer;
		this.price = price;
		this.publisher = publisher;
	}

	public BookVo() {
		// TODO Auto-generated constructor stub
	}

	public int getBookNum() {
		return bookNum;
	}

	public void setBookNum(int bookNum) {
		this.bookNum = bookNum;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	// 콘솔에 띄워주기 위해 작성한것.
	@Override
	public String toString() {
		return "BookVO [bookNum=" + bookNum + ", title=" + title + ", writer=" + writer + ", price=" + price
				+ ", publisher=" + publisher + "]";
	}

}
