package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day04Application {

	public static void main(String[] args) {
		SpringApplication.run(Day04Application.class, args);
	}

}
