package test02_Spring2;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import vo.BookVo;

public class BookDaoSpring {
	// dao가 의존하는 객체
	private JdbcTemplate jdbcTemplate;

	// 의존 객체 주입을 위한 생성자, 설정자
	public BookDaoSpring() {

	}

	public BookDaoSpring(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	/////////////////////////////////////////////////////////////
	public int insert(BookVo book) {
		String sql = "INSERT INTO BOOK(TITLE, PUBLISHER, PRICE, WRITER) VALUES(?,?,?,?)";
		Object[] args = { book.getTitle(), book.getPublisher(), book.getPrice(), book.getWriter() };
		return jdbcTemplate.update(sql, args);
//		return jdbcTemplate.update(sql, book.getTitle(), book.getPublisher(), book.getPrice(), book.getWriter());
	}

	// 전체 조회
	public List<BookVo> selectBookList() {
		String sql = "SELECT * FROM BOOK";
		// query()메소드는 데이터가 한 개 이상일때 사용
		return jdbcTemplate.query(sql, new BookMapper()); // 전부 가져오는 경우
	}

	// 특정 번호 조회 쿼리
	public BookVo selectBook(int bookNum) {
		String sql = "SELECT * FROM BOOK WHERE BOOK_NUM=?";
		// 데이터 값이 하나일 떄 queryForObject()메소드 사용
		return jdbcTemplate.queryForObject(sql, new BookMapper(), bookNum); // 하나만 가져오는 경우
	}

	// RowMapper 인터페이스
	// 원하는 형태의 결과값을 반환 할 수 있음.
	// select문으로 날아온 데이터를 여러개 받을 수 있고,
	// 하나만 받을 수도 있음.
	
	// mapRow의 형태
	// mapRow (ResultSet rs, int count)형태로 사용하는데
	// resultSet에 값을 담아와서 book객체에 저장
	// resultSet에 값을 count만큼 반복.

	class BookMapper implements RowMapper<BookVo> {
		@Override
		public BookVo mapRow(ResultSet rs, int count) throws SQLException {
			BookVo book = new BookVo();
			book.setBookNum(rs.getInt("BOOK_NUM"));
			book.setPrice(rs.getInt("PRICE"));
			book.setPublisher(rs.getString("PUBLISHER"));
			book.setTitle(rs.getString("TITLE"));
			book.setWriter(rs.getString("WRITER"));
			return book;
		}
	}
}
