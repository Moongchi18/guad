package test02_Spring2;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import vo.BookVo;

public class Test {

	public static void main(String[] args) {
		// 객체 아래처럼 new 하면 안된다.
		// BookDaoSpring dao = new BookDaoSpring();

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"test02_Spring2/applicationContext.xml");

		// dataSource 객체, jdbc Template 객체 장착된
		// 완제품 객체 가져오기

		BookDaoSpring dao = context.getBean("Dao", BookDaoSpring.class);

		BookVo book = new BookVo("스프링 책", "저자", 30000, "봉출판"); // import한 BookVo 클래스 생성
		System.out.println("insert 결과 : " + dao.insert(book));

		// 책 목록보기
		for (BookVo b : dao.selectBookList()) {
			System.out.println(b);
		}

		System.out.println(dao.selectBook(4));
	}
}
