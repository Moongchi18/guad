package test01_jdbc;

import vo.BookVo;

public class Test {

	public static void main(String[] args) {

		BookDao dao = new BookDao();

		BookVo book = new BookVo("1111", "2222", 25000,"3333");
		int result = dao.insertBook(book);
		System.out.println("insert result:" + result);

//		for (BookVo b : dao.selectAll()) { 
//			System.out.println(b);
//		}
	}
}
