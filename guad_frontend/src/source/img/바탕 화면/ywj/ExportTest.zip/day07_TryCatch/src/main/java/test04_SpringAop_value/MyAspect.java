package test04_SpringAop_value;

import org.aspectj.lang.JoinPoint;

public class MyAspect {

	public void myBefore(JoinPoint joinPoint) {

		// 메소드의 파라미터값을 가져와 사용, 수정이 필요할때.
		// joinPoin에 전달된 인자를 배열로 변환.
		Object[] param = joinPoint.getArgs();
		int n = (Integer) param[0];

		System.out.println("미리받은 숫자 " + n);
		System.out.println("배가 고프다");
	}

	public void afterReturning(Object result) {
		System.out.println("음식을 먹는다 냠냠");
		System.out.println("핵심사항 결과: " + result);
	}

	public void afterThrowing(Throwable ex) {
		System.out.println("핵심관심사항 도중 에러났대");
		System.out.println(ex.getMessage());
	}

	public void after() {
		System.out.println("설거지를 한다.");
	}
}
