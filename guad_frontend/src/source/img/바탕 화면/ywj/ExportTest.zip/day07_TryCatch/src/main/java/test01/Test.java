package test01;

public class Test {

	public static void main(String[] args) {
		Boy boy = new Boy();
		Girl girl = new Girl();
//		boy.doSomething();
		girl.doSomething();
	}
}
