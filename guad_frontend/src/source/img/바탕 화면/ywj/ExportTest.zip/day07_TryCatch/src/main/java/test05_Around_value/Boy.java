package test05_Around_value;

import java.util.Random;

public class Boy implements Person {

	public String doSomething(int n) throws Exception {

		// 핵심관심사항
		System.out.println("감자탕을 만든다" + n + "인분");
		if (new Random().nextBoolean()) {
			System.out.println("불이 났다!!!");
			throw new Exception("불났어!!");

		}
		return "감자탕 맛있네";
	}
}
