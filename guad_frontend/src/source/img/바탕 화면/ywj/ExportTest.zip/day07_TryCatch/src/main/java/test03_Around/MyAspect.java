package test03_Around;

import org.aspectj.lang.ProceedingJoinPoint;

public class MyAspect {

	public void myAround(ProceedingJoinPoint jointPoint) {
		System.out.println("배가 고프다");// before

		try {
			jointPoint.proceed();// 핵심관심사항 호출 시점. aop가 적용된 메소드 실행
			System.out.println("음식을 먹는다"); // after-returning

		} catch (Throwable e) { // Exception, Error의 조상
			System.out.println("불났음!!!!!! 엄마~!!!");// after-throwing
			e.printStackTrace();
		} finally {
			System.out.println("설거지를 한다.");// after
		}
	}
}
