package test03_Around;

public interface Person {
	public void doSomething() throws Exception;
}
