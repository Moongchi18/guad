package test01;

import java.util.Random;

public class Boy {

	public void doSomething() {
		//동작 시점 설명 Before
		System.out.println("배가고프다.");

		try {
			// 핵심 관심 사항(수행도중 예외 발생할 수 있음.)
			// 메소드 실행전 동작
			System.out.println("감자탕을 만든다.");
			if (new Random().nextBoolean()) {
				System.out.println("불이 났다!!!");
				throw new Exception("불났어!!!");
			}
			//after - returning : 메소드 실행 후 동작
			System.out.println("음식을 먹는다.");

		} catch (Exception ex) {
			//after -throwing : 메소드가 예외를 발생시킨 경우에 동작
			System.out.println("엄마를 부른다");
			
		} finally {
			//after : 위 모든 과정을 다 마치고 난후 동작
			System.out.println("설거지를 한다.");
		}
	}
}
