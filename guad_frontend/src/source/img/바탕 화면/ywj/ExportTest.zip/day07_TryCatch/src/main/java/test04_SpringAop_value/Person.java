package test04_SpringAop_value;

public interface Person {

	public String doSomething(int n) throws Exception;

}
