package test02_SpringAop;

public interface Person {
	public void doSomething() throws Exception;

}
