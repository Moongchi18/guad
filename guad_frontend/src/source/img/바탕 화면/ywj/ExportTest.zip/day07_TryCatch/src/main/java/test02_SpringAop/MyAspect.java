package test02_SpringAop;

public class MyAspect {

	public void myBefore() {
	// try 전
		System.out.println("배가 고프다.");
	}

	// 두번째 try문
	public void myAfterReturning() { // 핵심관심사 실행 후
		System.out.println("음식을 먹는다.");
	}

	// 예외 발생 catch문
	public void myAfterThrowing() { // 예외발생 했을떄
		System.out.println("엄마를 부른다.!!");
	}

	// try문 밖의 메서드
	public void myAfter() {
		System.out.println("설거지를 한다.");
	}

}
