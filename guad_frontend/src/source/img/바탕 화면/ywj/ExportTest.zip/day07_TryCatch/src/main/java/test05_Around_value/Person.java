package test05_Around_value;

public interface Person {

	//인자값 n
	public String doSomething(int n) throws Exception;
}
