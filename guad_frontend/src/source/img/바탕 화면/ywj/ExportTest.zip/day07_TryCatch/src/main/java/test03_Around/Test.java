package test03_Around;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) throws Exception {

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("test03_Around/applicationContext.xml");

//		Person p = context.getBean("Boy",Person.class);
		Person p = context.getBean("Girl", Person.class);
		p.doSomething();

	}
}
