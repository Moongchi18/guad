package test05_Around_value;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) throws Exception {

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("test05_Around_value/applicationContext.xml");

//		Person p = context.getBean("Boy",Person.class);
		Person p = context.getBean("Girl", Person.class);
		p.doSomething(5);

	}

}
