package burger.vo;

import lombok.Data;

@Data
public class RequestVo {
	private String password;
	private String email;
}
