package burger.dto;

import lombok.Data;

@Data
public class BasketDto {
	private String basketProduct;
	private String basketProductNum;
}
